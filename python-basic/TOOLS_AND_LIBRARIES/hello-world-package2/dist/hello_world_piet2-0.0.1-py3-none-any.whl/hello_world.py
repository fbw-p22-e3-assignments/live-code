def print_world():
    print('Hello World')