import setuptools

setuptools.setup(
    name="hello-world-piet2",
    version="0.0.1",
    author="Piet",
    description="prints hello world",
    py_modules=['hello_world'],
    package_dir={'': 'hello-world-piet2/src'}
)